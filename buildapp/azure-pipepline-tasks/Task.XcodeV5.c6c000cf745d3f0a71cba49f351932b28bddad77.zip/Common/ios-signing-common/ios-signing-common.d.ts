/**
 * Creates a temporary keychain and installs the P12 cert in the temporary keychain
 * @param keychainPath the path to the keychain file
 * @param keychainPwd the password to use for unlocking the keychain
 * @param p12CertPath the P12 cert to be installed in the keychain
 * @param p12Pwd the password for the P12 cert
 * @param useKeychainIfExists Pass false to delete and recreate a preexisting keychain
 */
export declare function installCertInTemporaryKeychain(keychainPath: string, keychainPwd: string, p12CertPath: string, p12Pwd: string, useKeychainIfExists: boolean): Promise<void>;
/**
 * Finds an iOS codesigning identity in the specified keychain
 * @param keychainPath
 * @returns {string} signing identity found
 */
export declare function findSigningIdentity(keychainPath: string): Promise<string>;
/**
 * Get Cloud entitlement type Production or Development according to the export method - if entitlement doesn't exists in provisioning profile returns null
 * @param provisioningProfilePath
 * @param exportMethod
 * @returns {string}
 */
export declare function getCloudEntitlement(provisioningProfilePath: string, exportMethod: string): Promise<string>;
/**
 * Find the UUID and Name of the provisioning profile and install the profile
 * @param provProfilePath
 * @returns { provProfileUUID, provProfileName }
 */
export declare function installProvisioningProfile(provProfilePath: string): Promise<{
    provProfileUUID: string;
    provProfileName: string;
}>;
/**
 * Find the Name of the provisioning profile
 * @param provProfilePath
 * @returns {string} Name
 */
export declare function getProvisioningProfileName(provProfilePath: string): Promise<string>;
/**
 * Find the type of the iOS provisioning profile - app-store, ad-hoc, enterprise or development
 * @param provProfilePath
 * @returns {string} type
 */
export declare function getiOSProvisioningProfileType(provProfilePath: string): Promise<string>;
/**
 * Find the type of the macOS provisioning profile - app-store, developer-id or development.
 * mac-application is a fourth macOS export method, but it doesn't include signing.
 * @param provProfilePath
 * @returns {string} type
 */
export declare function getmacOSProvisioningProfileType(provProfilePath: string): Promise<string>;
/**
 * Find the bundle identifier in the specified Info.plist
 * @param plistPath
 * @returns {string} bundle identifier
 */
export declare function getBundleIdFromPlist(plistPath: string): Promise<string>;
/**
 * Delete specified iOS keychain
 * @param keychainPath
 */
export declare function deleteKeychain(keychainPath: string): Promise<void>;
/**
 * Unlock specified iOS keychain
 * @param keychainPath
 * @param keychainPwd
 */
export declare function unlockKeychain(keychainPath: string, keychainPwd: string): Promise<void>;
/**
 * Delete provisioning profile with specified UUID in the user's profiles directory
 * @param uuid
 */
export declare function deleteProvisioningProfile(uuid: string): Promise<void>;
/**
 * Gets the path to the iOS default keychain
 */
export declare function getDefaultKeychainPath(): Promise<string>;
/**
 * Gets the path to the temporary keychain path used during build or release
 */
export declare function getTempKeychainPath(): string;
/**
 * Get several x509 properties from the certificate in a P12 file.
 * @param p12Path Path to the P12 file
 * @param p12Pwd Password for the P12 file
 */
export declare function getP12Properties(p12Path: string, p12Pwd: string): Promise<{
    fingerprint: string;
    commonName: string;
    notBefore: Date;
    notAfter: Date;
}>;
/**
 * Delete certificate with specified SHA1 hash (thumbprint) from a keychain.
 * @param keychainPath
 * @param certSha1Hash
 */
export declare function deleteCert(keychainPath: string, certSha1Hash: string): Promise<void>;
/**
 * Get the friendly name from the private key in a P12 file.
 * @param p12Path Path to the P12 file
 * @param p12Pwd Password for the P12 file
 */
export declare function getP12PrivateKeyName(p12Path: string, p12Pwd: string): Promise<string>;
